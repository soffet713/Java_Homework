
public class ArraySum{
	
	public ArraySum(){
		
	}
	
	
	//trying to check the sum of two numbers in an array
	private boolean CheckArraySumA(int[] array, int k){
		
		boolean sum = false;
		for(int i = 0; i < array.length; i++){
			if(!sum){
				for (int j = i + 1; j < array.length; j++){
					if (array[i] + array[j] == k && j != i && !sum){
						System.err.println("There are two numbers in the array with a sum of "
								+ k);
						sum = true;
						return true;
					}
				}
			}
		}
		
		if(!sum)
			System.err.println("There are no two numbers in the array with a sum of "
					+ k);
		return false;
	}
	
	
	//trying to check the sum of two numbers in a sorted array
	private boolean CheckArraySumB(int[] array, int k){
		
		mergeSort(array);
		
		boolean sum = false;
		
		int start = 0;
		int length = array.length-1;
		int end = array[length];
		int beginning = array[start];
		for(int i = 0; i < length; i++){
			if(start < length && !sum){
				if(beginning + end == k){
					sum = true;
					System.err.println("There are two numbers in the array with a sum of "
							+ k);
					return true;
				}
				if(beginning + end < k){
					start += 1;
					beginning = array[start];
				}
				if(beginning + end > k){
					length -= 1;
					end = array[length];
				}
			}
		}
		
		System.err.println("There are no two numbers in the array with a sum of "
				+ k);
		return false;
		
	}
	
	
	//trying to check the sum of 3 numbers
	private boolean CheckArraySum3(int[] array, int k){
		
		mergeSort(array);
		
		boolean sum = false;
		
		int start = 0;
		int length = array.length-1;
		int tsugi = start + 1;
		int end = array[length];
		int beginning = array[start];
		int next = array[tsugi];
		
		for(int i = 0; i < length * length; i++){
			if(start<tsugi && tsugi<length && !sum){
				if(end + next + beginning < k){
					if(tsugi == length - 1){
						start++;
						beginning = array[start];
						tsugi = start;
					}
					
					tsugi++;
					next = array[tsugi];
				}
				else if(end + next + beginning > k){
					if(tsugi == length -1){
						length--;
						end = array[length];
					}
				
					tsugi = start + 1;
					next = array[tsugi];
				}
				else{
					sum = true;
					System.err.println("There are three numbers in the array with a sum of "
							+ k);
					return true;
				}
			}
		}
		
		System.err.println("There are no three numbers in the array with a sum of "
				+ k);
		
		return false;
	}
	
	
	//mergeSort
	public void mergeSort(int[] x){
		int[] tempArray = new int[x.length];
		mergeSort(x, tempArray, 0, x.length - 1);
		
	}
	
	private void mergeSort( int [ ] a, int [ ] tmpArray,
            int left, int right ) {
     	if( left < right )
     	{
         	int center = ( left + right ) / 2;
         	mergeSort( a, tmpArray, left, center );
         	mergeSort( a, tmpArray, center + 1, right );
         	merge( a, tmpArray, left, center + 1, right );
     	}
 	}

 
	private void merge( int [ ] a, int [ ] tmpArray,
        int leftPos, int rightPos, int rightEnd ){
		int leftEnd = rightPos - 1;
		int tmpPos = leftPos;
		int numElements = rightEnd - leftPos + 1;

     
		while( leftPos <= leftEnd && rightPos <= rightEnd )
			if( a[ leftPos ] <= a[ rightPos ] )
             tmpArray[ tmpPos++ ] = a[ leftPos++ ];
			else
             tmpArray[ tmpPos++ ] = a[ rightPos++ ];

		while( leftPos <= leftEnd )
			tmpArray[ tmpPos++ ] = a[ leftPos++ ];
		
		while( rightPos <= rightEnd )
			tmpArray[ tmpPos++ ] = a[ rightPos++ ];

     
		for( int i = 0; i < numElements; i++, rightEnd-- )
			a[ rightEnd ] = tmpArray[ rightEnd ];
	} //end of mergeSort
	
	
	/*test methods on an array(s)*/
	public static void main( String [ ] args ){
		
		ArraySum x = new ArraySum();
		
		int k = 273;
		int[] array = new int[100077];
		for(int i = 0; i < array.length; i++){
			array[i] = (i%15) * 3;
		}
		
		array[59777] = 200;
		array[60000] = 73;
		
		
		//test checking sum in an array that has two numbers whose sum equals the number
		long startTime, finishTime;
    	startTime = System.currentTimeMillis();
    	x.CheckArraySumA(array, k);
		finishTime = System.currentTimeMillis();
		System.err.println("Elapsed time for CheckSum A (milliseconds): " +
				(finishTime - startTime));

		//test checking the sum in a sorted array that has two numbers whose sum equals the number
		startTime = System.currentTimeMillis();
    	x.CheckArraySumB(array, k);
		finishTime = System.currentTimeMillis();
		System.err.println("Elapsed time for CheckSum B (milliseconds): " +
				(finishTime - startTime));
		
		
		//re-make the array to test again
		for(int i = 0; i < array.length; i++){
			array[i] = (i%15) * 3;
		}
		
		
		//test checking the sum in an array that doesn't have two numbers equal to the number
    	startTime = System.currentTimeMillis();
    	x.CheckArraySumA(array, k);
		finishTime = System.currentTimeMillis();
		System.err.println("Elapsed time for a failing CheckSum A (milliseconds): " +
				(finishTime - startTime));

		
		//test again with a sorted array that does not contain two values adding up to the number
		startTime = System.currentTimeMillis();
    	x.CheckArraySumB(array, k);
		finishTime = System.currentTimeMillis();
		System.err.println("Elapsed time for a failing CheckSum B (milliseconds): " +
				(finishTime - startTime));
		
		
		//re-make the array to test again
		for(int i = 0; i < array.length; i++){
			array[i] = (i%15) * 3;
		}
		
		array[99999] = 200;
		array[3597] = 70;
		array[3972] = 3;
		
		
		//test checking the sum of three numbers in an array
    	startTime = System.currentTimeMillis();
    	x.CheckArraySum3(array, k);
		finishTime = System.currentTimeMillis();
		System.err.println("Elapsed time for CheckSum of 3 numbers (milliseconds): " +
				(finishTime - startTime));
		
	}

}
