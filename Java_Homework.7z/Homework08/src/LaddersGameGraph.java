import java.util.*;
import java.io.*;

public class LaddersGameGraph {
	
	int numWords = 0;
	adjListHead[] wordGraph = new adjListHead[5000];
	
	public LaddersGameGraph(){
		
	}
	
	public void ReadDictionary(String dictionary){
		
	     String word;
	     try{
	         FileReader inFile = new FileReader(dictionary);
	         StreamTokenizer in = new StreamTokenizer(inFile);

	         in.nextToken();
	         while(in.ttype != in.TT_EOF){
	             word = in.sval;
	             wordGraph[numWords] = new adjListHead(word, null);
	             in.nextToken();
	             numWords++;
	         }
	     }
	     catch(IOException e) {}
	}
	
	public void linkString(int s, int j){
		listNode node = wordGraph[s].next;
		if(node==null){
			wordGraph[s].next = new listNode(j);
		}
		else{
			wordGraph[s].next = new listNode(j);
			wordGraph[s].next.next = node;
		}
	}
	
	public void checkAdjacency(int s, int j){
		
		int difChar = 0;
		String word1 = wordGraph[s].str;
		String word2 = wordGraph[j].str;
		
		for(int i = 0; i < word1.length(); i++){
			if(word1.charAt(i) != word2.charAt(i))
				difChar++;
		}
		
		if (difChar == 1){
			linkString(s, j);
		}
	}
	
	public void printAdjacentWords(){
		for(int i = 0; i < numWords; i++){
			System.err.println("Adjacent words of " + wordGraph[i].str + " are: ");
			listNode node = wordGraph[i].next;
			while(node!=null){
				System.err.println(" " + wordGraph[node.wordIndex].str);
				node = node.next;
			}
		}
	}
	
	public void adjacencyTest(String dictionary){
		for(int i = 0; i < wordGraph.length; i++){
			if(wordGraph[i]!=null){
				for(int j = 0; j < wordGraph.length; j++){
					if(wordGraph[j]!=null && i!=j)
						checkAdjacency(i, j);
				}
			}
		}
	}
	
	public boolean findLadders(String dictionary, String word1, String word2){
		ReadDictionary(dictionary);
		adjacencyTest(dictionary);
		
		//
		//first check to make sure the two words are not the same
		//
		int same = 0;
		for(int r = 0; r<word1.length();r++){
			if(word1.charAt(r) == word2.charAt(r))
				same++;
		}
		
		if(same==5){
			System.err.println(word1);
			return true;
		}
		
		//
		//find the location in the array of adjHeadLists of the first word
		//
		int word1index = -1;
		for(int i = 0; i < numWords; i++){
			int length = 0;
			for(int x = 0; x < word1.length(); x++){
				if(wordGraph[i].str.charAt(x) == word1.charAt(x)){
					length++;
				}
			}
			if(length == 5){
				word1index = i;
			}
		}
		
		//
		//Use a queue to look at each vertex and give them a parent if they have one
		//
		ListQueue myQueue = new ListQueue();
		
		wordGraph[word1index].parent = -1;
		myQueue.enqueue(word1index);
		while(myQueue.size!=0){
			int vertexParent = myQueue.dequeue();
			listNode node = wordGraph[vertexParent].next;
			while(node!=null){
				if(wordGraph[node.wordIndex].parent == -2){
					wordGraph[node.wordIndex].parent = vertexParent;
					myQueue.enqueue(node.wordIndex);
				}
				node = node.next;
			}
		}
		
		//
		//find the location of the last word
		//
		int endwordindex = -1;
		for(int j = 0; j < numWords; j++){
			int length = 0;
			for(int x = 0; x < word2.length(); x++){
				if(wordGraph[j].str.charAt(x) == word2.charAt(x)){
					length++;
				}
			}
			if(length == 5){
				endwordindex = j;
			}
		}
		
		//
		//Find the ladder between the two words
		//
		int[] parents = new int[5000];
		int parentlocation = 0; //integer that marks where we are in the array of "parent" integers and the size of the array
		parents[0] = endwordindex;
		parentlocation++;
		int parentindex = wordGraph[endwordindex].parent;
		parents[parentlocation] = parentindex;
		while(parentindex!=-2){
			if(parentindex == word1index){
				//
				//for loop looks through the array and prints each parent
				//	**the resulting list is the shortest ladder**
				//
				for(int z = parentlocation; z>=0; z--){
					System.err.println(wordGraph[parents[z]].str);
				}
				return true;
			}
			else{
				parentindex = wordGraph[parentindex].parent;
				parentlocation++;
				parents[parentlocation] = parentindex;
			}
		}
		System.err.println("There is no ladder from " + word1 + " to " + word2);
		return false;
	}
		
	public static void main( String [ ] args ){
		
		String TestFile = args[0];
		String word1 = args[1];
		String word2 = args[2];
		System.err.println(word2 + " ; " + word1); //print the two words provided
		LaddersGameGraph test = new LaddersGameGraph();
		
		test.findLadders(TestFile, word2, word1);
		
		System.err.println("");
		System.err.println(word1 + " ; " + word2);
		test.findLadders(TestFile, word1, word2);
	}
}

class listNode{
	
	int wordIndex;
	listNode next;

    public listNode(int myWordIndex)
    {
        this.wordIndex = myWordIndex;
        this.next = null;
    }
}

class adjListHead{
	
	String str;
	listNode next;
	int parent = -2;
	
	public adjListHead(String s, listNode j){
		str = s;
		next = null;
	}
}

interface MyQueue {
	
	public void makeEmpty();
	public boolean isEmpty();
	
	public void enqueue (int key);
	public int front();
	int dequeue();
}

class ListQueue implements MyQueue {
	
	List<Integer> theList;
	int size;
	
	ListQueue() {
		makeEmpty();
	}
	
	public void makeEmpty() {
		theList = new LinkedList<Integer>();
		size = 0;
	}
	
	public boolean isEmpty() {
		return (size == 0);
	}
	
	public int dequeue() {
		int result = -1;
		if (size == 0) 
			System.err.println("Error: Dequeue failed because queue is empty");
		else {
			result = theList.get(0);
			theList.remove(0);
			size--;
		}
		return result;
	}

	public int front() {
		int result = -1;
		if (size == 0) 
			System.err.println("Error: Front failed because queue is empty");
		else 
			result = theList.get(0);
		return result;
	}
		
	public void enqueue(int key) {
		theList.add(size,key);
		size++;
	}
}