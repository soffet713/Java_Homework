

public class MyBinaryHeap {
	
	private static int capacity = 5000000;

    private int currentSize;
    private int[] array;
	
	public MyBinaryHeap( )
    {
        this( capacity );
    }

    
    public MyBinaryHeap( int capacity )
    {
        currentSize = 0;
        array = new int[ capacity + 1 ];
    }

    
    public void insert( int x )
    {
        if( currentSize == array.length - 1 )
        	System.err.println("Cannot insert, heap is full");

            // Percolate up
        int hole = ++currentSize;
        for( ; hole > 1 && (x - array[ hole / 2 ])< 0; hole /= 2 )
            array[ hole ] = array[ hole / 2 ];
        array[ hole ] = x;
    }

    public static void main( String [ ] args ){
    	
    	//reverse sorted
    	MyBinaryHeap heap = new MyBinaryHeap(5000000);
    	
    	long startTime, finishTime;
    	startTime = System.currentTimeMillis();
    	for (int i = 5000000; i > 0; i--){
    		
    		heap.insert(i);
    		
    	}
    	finishTime = System.currentTimeMillis();
		System.err.println(
				"Elapsed time for Insert method reverse sorted (milliseconds): " +
				(finishTime - startTime));
		
		//sorted
		MyBinaryHeap heap1 = new MyBinaryHeap(5000000);
    	startTime = System.currentTimeMillis();
    	for (int i = 0; i < 5000000; i++){
    		
    		heap1.insert(i);
    		
    	}
    	finishTime = System.currentTimeMillis();
		System.err.println(
				"Elapsed time for Insert method sorted (milliseconds): " +
				(finishTime - startTime));
        
		
		//random
		MyBinaryHeap heap2 = new MyBinaryHeap(5000000);
    	startTime = System.currentTimeMillis();
    	int x = 23;
    	for (int i = 0; i < 5000000; i++){
    		
    		int value = (x+1)%23 * 3;
    		heap2.insert(value);
    		x++;
    		
    	}
    	finishTime = System.currentTimeMillis();
		System.err.println(
				"Elapsed time for Insert method random (milliseconds): " +
				(finishTime - startTime));
		
    }

}
