
public class MyBinaryHeapBuild {

	private int size;
	private int[] array;
	
	public MyBinaryHeapBuild(int[] items){
		
		size = items.length;
		array = (int[]) new int[(size+2) * 11 / 10];
		
		for(int i = 0; i<items.length; i++){
			array[i] = items[i];
		}
		
		buildMyHeap();
	}
	
	
	private void myPercolateDown(int hole){
		
		int child;
		int tmp = array[hole];
		
		for( ; hole*2<=size; hole = child){
			
			child = hole*2;
			if(child != size && (array[child+1]-array[child])<0)
				child++;
			if(array[child] - tmp < 0)
				array[hole] = array[child];
			else
				break;
		}
		array[hole] = tmp;
		
	}
	
	private void buildMyHeap(){
		
		for(int i = size/2; i > 0; i--)
			myPercolateDown(i);
	}
	
	public static void main( String [ ] args ){
		
		int[] buildheap = new int[5000000];
		int x = 0;
		
		for(int i = buildheap.length - 1; i > 0; i--){
			
			buildheap[i] = x++;
			
		}
		
		long startTime, finishTime;
    	startTime = System.currentTimeMillis();
		MyBinaryHeapBuild myheap = new MyBinaryHeapBuild(buildheap);
		finishTime = System.currentTimeMillis();
		System.err.println(
				"Elapsed time for BuildHeap method reverse sorted (milliseconds): " +
				(finishTime - startTime));
		
		
		x = 1;
		for(int i = 0; i < buildheap.length; i++){
			
			buildheap[i] = x++;
			
		}
		
		startTime = System.currentTimeMillis();
		MyBinaryHeapBuild myheap1 = new MyBinaryHeapBuild(buildheap);
		finishTime = System.currentTimeMillis();
		System.err.println(
				"Elapsed time for BuildHeap method sorted (milliseconds): " +
				(finishTime - startTime));
		
		
		x = 23;
		for(int i = 0; i < buildheap.length; i++){
			
			buildheap[i] = (x+1)%23 * 3;
			x++;
			
		}
		
		startTime = System.currentTimeMillis();
		MyBinaryHeapBuild myheap2 = new MyBinaryHeapBuild(buildheap);
		finishTime = System.currentTimeMillis();
		System.err.println(
				"Elapsed time for BuildHeap method random (milliseconds): " +
				(finishTime - startTime));
		
	}
}
