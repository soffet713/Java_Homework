import java.util.ArrayList;

public class TestMazeIO {
	public static void main(String[] args) {

		int numCols;
		int numRows;
		int numCells;            // should be equal to numCols*numRows
		
		int numExtraConnections; // A number >= 0 of "extra walls"
		                         // to be removed to increase the number
		                         // of possible paths in the maze
		int numBrickWalls;       // Number (>= 0) of brick walls you want
		int numAdobeWalls;       // Number (>= 0) of adobe walls you want
		
		int brickCost = 5; 		// set this to any number >= 1
		int adobeCost = 2;		// set this to any number >= 1
		
		// you always need the next line, whether using
		// graphics or not
		MazeIO mazeIO = new MazeIO();
		
		// An example (with no graphics) that generates
		// a maze and writes it into a maze file (which   
		// your solver could then read and process.)
		if (false) {
			numCols = 13;
			numRows = 7;
			// use 0 for each of the following for simple "standard"
			// maze with no cycles and no brick/adobe walls.
			// Breadth-first search would successfully solve such mazes.
			// You'll use Dijstra's algorithm to solve these "enhanced" mazes.
			numExtraConnections = 10;
			numBrickWalls = 10;       
			numAdobeWalls = 5;
			numCells = numCols * numRows;
			mazeIO.genMaze(numRows, numCols, numExtraConnections, numBrickWalls, numAdobeWalls);
			mazeIO.writeMazeFile("maze1.text");
		}

		// An example (just like the one above but WITH graphics) 
		// that generates a maze, writes it into a maze file, 
		// displays it in a window, and allows you to interactively 
		// move around the maze with keyboard keys.
		if (false) {
			numCols = 13;
			numRows = 7;
			numExtraConnections = 10;
			numBrickWalls = 10;       
			numAdobeWalls = 5;
			numCells = numCols * numRows;
			
			// Initialize window for a numRows*numCols maze.  You
			// must call mazeIO.genMaze afterward or you won't
			// have a useful maze.
			mazeIO.initGraphics(numRows,numCols);
			mazeIO.genMaze(numRows, numCols, numExtraConnections, numBrickWalls, numAdobeWalls);
			
			// Next line initializes an interactive "player" in cell 0.
			mazeIO.initializePlayer(0);	
			// Next line makes sure graphics system properly calculates
			// player and solution path costs.
			mazeIO.setWallCosts(brickCost, adobeCost);
			
			// Even if you are using graphics, you can still 
			// write out the generate graph if you wish
			mazeIO.writeMazeFile("maze2.text");
		}
		
		// An example, WITH graphics,  that reads a maze file, 
		// displays it in a window, allows you to interactively 
		// move around the maze with keyboard keys.
		if (true) {
			mazeIO.initializePlayer(0);	
			mazeIO.setWallCosts(brickCost, adobeCost);
			
			numCells = mazeIO.initGraphics("smallmaze3.txt");
			mazeIO.initGraphics("smallmaze3.txt");
		}
	
		// Finally, if you have written your solver, you can
		// see you path displayed in the graphics window.
		//
		// First find all shortest paths from cell 0 (or 
		//  some other given start cell.
		// Next extract the shortest path and store it
		//  in an ArrayList so you can pass it to the graphics
		//  for display.
		
		// this won't work until you write solveMaze()
		// and makeSolutionPath()
		if (false) { 
			//solveMaze(0); 
			//ArrayList solutionPath = makeSolutionPath(numCells-1); 
			//mazeIO.drawSolutionPath(solutionPath);
		}
	
		// But this will work (as long as one of the with-graphics
		// examples above is also set 'true')
		// It simply shows how you can create 
		// and draw a trivial path, from cell 0 to cell 1.
		if (false) {
			ArrayList solutionPath = new ArrayList<Integer>();
			solutionPath.add(0,0);
			solutionPath.add(1,1);
			mazeIO.drawSolutionPath(solutionPath);
		}
	} 
}

