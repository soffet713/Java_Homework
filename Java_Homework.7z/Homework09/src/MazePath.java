import java.util.*;
import java.io.*;

public class MazePath {
	int numVertices = 0;
	int size = 0;
	vertexNode[] mazeGraph;
	
	public MazePath(){
		
	}
	
	public void addEdge(int s, int j, int weight){
		edgeNode node = mazeGraph[s].next;
		if(node==null){
			mazeGraph[s].next = new edgeNode(j, weight);
		}
		else{
			mazeGraph[s].next = new edgeNode(j, weight);
			mazeGraph[s].next.next = node;
		}
	}
	
	//
	//Find the smallest distance unknown vertex
	//
	public vertexNode findSmallest(){
		vertexNode v = null;
		int location = 0;
		while(v==null){
			if(!mazeGraph[location].known){
				v = mazeGraph[location];
			}
			else
				location++;
		}
		for(int i = location; i<numVertices; i++){
			if(!mazeGraph[i].known){
				if(mazeGraph[i].distance<v.distance){
					v = mazeGraph[i];
				}
			}
		}
		return v;
	}
	
	public boolean findMinimumPath(String mazeFileName, int brickweight, int adobeweight, 
			int startCell, int endCell){
		
		boolean done = false;
		
		int row, col;
		int node1, node2; 
		int weight = Integer.MAX_VALUE;
		String wallType;
		Scanner sc;
		
		row = 0;
		col = 0;
		node1 = node2 = -1;
		
		try{
			sc = new Scanner(new File(mazeFileName));
		
			if(sc.hasNextInt()) row = sc.nextInt();
			else System.err.println("input maze file format error!");
			if(sc.hasNextInt()) col = sc.nextInt();
			else System.err.println("input maze file format error!");
			
			numVertices = row * col;
			
			//create instances of vertex nodes
			mazeGraph = new vertexNode[numVertices];			
			for(int i=0; i<numVertices; i++) 
				mazeGraph[i] = new vertexNode(i);			
			
			while(sc.hasNext()) {
				//read each line
				if(sc.hasNextInt()) node1 = sc.nextInt();
				else {
					System.err.println("input maze file format error!");
					return false;
				}
				
				if(sc.hasNextInt()) node2 = sc.nextInt();
				else{
					System.err.println("input maze file format error!");
					return false;
				}
				
				if(sc.hasNext()) wallType = sc.next();
				else{ 
					System.err.println("input maze file format error!");
					return false;
				}
				
				//add edges to adjacent list
				if(wallType.equalsIgnoreCase("none")) weight = 0;
				else if(wallType.equalsIgnoreCase("adobe")) weight = adobeweight;
				else if(wallType.equalsIgnoreCase("brick")) weight = brickweight;
				else{ 
					System.err.println("wall type error in input maze file!");
					return false;
				}
				
				addEdge(node1, node2, weight);
				addEdge(node2, node1, weight);
			}
			
			sc.close();
		}catch(FileNotFoundException e) {
			System.err.println("Cannot find file!");
		}
		
		//
		//Dijkstra's algorithm
		//
		vertexNode s = mazeGraph[startCell];
		s.distance = 0;
		
		while(!done){
			vertexNode v = findSmallest();
			mazeGraph[v.vertexID].known = true;
			
			edgeNode adj = v.next;
			while(adj!=null){
				if(!mazeGraph[adj.vertex].known){
					if(v.distance + adj.weight < mazeGraph[adj.vertex].distance){
						mazeGraph[adj.vertex].distance = v.distance + adj.weight + 1;
						mazeGraph[adj.vertex].pre = v;
					}
				}
				adj = adj.next;
			}
			
			if(v==mazeGraph[endCell]){
				vertexNode path = mazeGraph[endCell];
				System.err.println("Shortest Path: ");
				while(path!=mazeGraph[startCell]){
					System.err.println(" " + path.vertexID);
					path = path.pre;
				}
				System.err.println(startCell);
				System.err.println("Minimum path exists!");
				done = true;
				return true;
			}
		}
		return false;
	}
		
	public static void main( String[ ] args ){
		
		String TestFile = args[0];
		MazePath test = new MazePath();
		
		test.findMinimumPath(TestFile, 5, 2, 0, 52);
	}
}

class edgeNode{
	
	int vertex;
	edgeNode next;
	int weight;

    public edgeNode(int myVertex, int wallWeight)
    {
        this.vertex = myVertex;
        this.next = null;
        this.weight = wallWeight;
    }
}

class vertexNode{
	
	edgeNode next;
	boolean known = false;
	int distance = Integer.MAX_VALUE;
	vertexNode pre;
	int vertexID;
	
	public vertexNode(int id){
		vertexID = id;
	}
}
